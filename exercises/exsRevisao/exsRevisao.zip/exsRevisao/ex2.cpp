#include<stdio.h>
#include<stdlib.h>
int main(){
	int cont = 0;
	while(cont<=100){
		printf("%d\n", cont);
		cont++;
	}
	return 0;
}
