#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){
	char nome;
	printf("Digite um nome: ");
	nome = getchar;
	printf("%zu", strlen(nome));
	return 0;
	
}
